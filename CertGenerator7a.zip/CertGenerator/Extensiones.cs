﻿
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.X509;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace LxTools.X509Generator
{
    public enum CertificateKeyUsage
    {
        EncipherOnly = 1,
        CRLSigning = 2,
        CertificateSigning = 4,
        KeyAgreement = 8,
        DataEncipherment = 16, // 0x00000010
        KeyEncipherment = 32, // 0x00000020
        NonRepudiation = 64, // 0x00000040
        DigitalSignature = 128, // 0x00000080
        DecipherOnly = 32768, // 0x00008000
    }

    public enum CertificateEnhancedKeyUsage
    {
        AnyPurpose,
        ClientAuthentication,
        CodeSigning,
        SecureEmail,
        IpsecEndSystem,
        IpsecTunnel,
        IpsecUser,
        OcspSigning,
        ServerAuthentication,
        SmartcardLogon,
        TimeStamping,
        DocumentSigning,
        NetscapeServerGatedCrypto,
        MicrosoftServerGatedCrypto,
    }

    internal class ExtensionInfo
    {
        private object extensionType;
        private bool isCritical;
        private bool extendedKeyUsage;

        public ExtensionInfo(object extension, bool critical, bool extKeyUsage)
        {
            this.extensionType = extension;
            this.isCritical = critical;
            this.extendedKeyUsage = extKeyUsage;
        }

        public object ExtensionType => this.extensionType;

        public bool ExtendedKeyUsage => this.extendedKeyUsage;
    }

    public class Extensions
    {
        internal List<ExtensionInfo> extensionInfo = new List<ExtensionInfo>();

        public Extensions()
        {
            this.KeyUsageIsCritical = false;
            this.EnhancedKeyUsageIsCritical = false;
        }

        public bool KeyUsageIsCritical { get; set; }

        public bool EnhancedKeyUsageIsCritical { get; set; }

        public void AddKeyUsage(CertificateKeyUsage keyUsage)
        {
            try
            {
                this.extensionInfo.Add(new ExtensionInfo((object)keyUsage, this.KeyUsageIsCritical, false));
            }
            catch
            {
                throw;
            }
        }

        public void AddEnhancedKeyUsage(CertificateEnhancedKeyUsage enhancedKeyUsage)
        {
            try
            {
                switch (enhancedKeyUsage)
                {
                    case CertificateEnhancedKeyUsage.DocumentSigning:
                        this.extensionInfo.Add(new ExtensionInfo((object)new DerObjectIdentifier("1.3.6.1.4.1.311.10.3.12"), this.EnhancedKeyUsageIsCritical, true));
                        break;
                    case CertificateEnhancedKeyUsage.NetscapeServerGatedCrypto:
                        this.extensionInfo.Add(new ExtensionInfo((object)new DerObjectIdentifier("2.16.840.1.113730.4.1"), this.EnhancedKeyUsageIsCritical, true));
                        break;
                    case CertificateEnhancedKeyUsage.MicrosoftServerGatedCrypto:
                        this.extensionInfo.Add(new ExtensionInfo((object)new DerObjectIdentifier("1.3.6.1.4.1.311.10.3.3"), this.EnhancedKeyUsageIsCritical, true));
                        break;
                    default:
                        object extension = (object)null;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.AnyPurpose)
                            extension = (object)KeyPurposeID.AnyExtendedKeyUsage;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.ClientAuthentication)
                            extension = (object)KeyPurposeID.IdKPClientAuth;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.CodeSigning)
                            extension = (object)KeyPurposeID.IdKPCodeSigning;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.SecureEmail)
                            extension = (object)KeyPurposeID.IdKPEmailProtection;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.IpsecEndSystem)
                            extension = (object)KeyPurposeID.IdKPIpsecEndSystem;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.IpsecTunnel)
                            extension = (object)KeyPurposeID.IdKPIpsecTunnel;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.IpsecUser)
                            extension = (object)KeyPurposeID.IdKPIpsecUser;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.OcspSigning)
                            extension = (object)KeyPurposeID.IdKPOcspSigning;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.ServerAuthentication)
                            extension = (object)KeyPurposeID.IdKPServerAuth;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.SmartcardLogon)
                            extension = (object)KeyPurposeID.IdKPSmartCardLogon;
                        if (enhancedKeyUsage == CertificateEnhancedKeyUsage.TimeStamping)
                            extension = (object)KeyPurposeID.IdKPTimeStamping;
                        this.extensionInfo.Add(new ExtensionInfo(extension, this.EnhancedKeyUsageIsCritical, true));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        public void AddEnhancedKeyUsage(Oid extensionOID)
        {
            try
            {
                this.extensionInfo.Add(new ExtensionInfo((object)new DerObjectIdentifier(extensionOID.Value), this.EnhancedKeyUsageIsCritical, true));
            }
            catch
            {
                throw;
            }
        }
    }
}
