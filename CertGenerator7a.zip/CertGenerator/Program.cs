﻿// LxTools.X509Manager : v.1.0 - 3mar24
//
// * Inspirado en : SignLib.Certificates.X509CertificateGenerator  Version=1.0 
//
// * Usamos iTextSharp5 por BouncyCastle, no usamos ninguna rutina para PDFs por ahora
//

//using iTextSharp.text.pdf;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Utilities.Net;
using Org.BouncyCastle.X509;

using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using SyCert = System.Security.Cryptography.X509Certificates;
using System.Text;


namespace LxTools.X509Generator
{
    public enum KeySize
    {
        KeySize512Bit = 512, // 0x00000200
        KeySize1024Bit = 1024, // 0x00000400
        KeySize2048Bit = 2048, // 0x00000800
        KeySize4096Bit = 4096, // 0x00001000
    }

    public enum SignatureAlgorithm
    {
        SHA1WithRSA,
        SHA256WithRSA,
        SHA512WithRSA,
        MD5WithRSA,
    }

    public enum SubjectType
    {
        C,
        E,
        L,
        O,
        T,
        CN,
        DC,
        OU,
        ST,
        UID,
        STREET,
        PSEUDONYM,
        NAME,
        EMAILADDRESS,
        SERIALNUMBER,
        SURNAME,
        GIVENNAME,
        INITIALS,
    }

    public class X509CertificatesX
    {
        private const long _DefaultSerialNumber_ = -9223372036854775808;
        private IDictionary attrs;
        private IList ord;
        private X509Certificate rootCert;
        private AsymmetricCipherKeyPair rootKeyPair;

        public string SubjectAlternativeNames { get; set; }

        public DateTime ValidFrom { get; set; }

        public DateTime ValidTo { get; set; }

        public KeySize KeySize { get; set; }

        public SignatureAlgorithm SignatureAlgorithm { get; set; }

        public long SerialNumber { get; set; }

        public string FriendlyName { get; set; }

        public string Subject { get; set; }

        public Extensions Extensions { get; set; }

        public X509CertificatesX()
        {
            this.Extensions = new Extensions();
            this.ValidFrom = DateTime.Now;
            this.ValidTo = this.ValidFrom.AddYears(1);
            this.KeySize = KeySize.KeySize1024Bit;
            this.SignatureAlgorithm = SignatureAlgorithm.SHA1WithRSA;
            this.FriendlyName = string.Empty;
            this.SerialNumber = long.MinValue;
            this.rootCert = (X509Certificate)null;
            this.rootKeyPair = (AsymmetricCipherKeyPair)null;
            this.attrs = (IDictionary)new Hashtable();
            this.ord = (IList)new ArrayList();
        }

        public void AddToSubject(SubjectType subjectType, string subjectTypeValue)
        {
            if (subjectType == SubjectType.C)
            {
                this.attrs[(object)X509Name.C] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.C);
            }
            if (subjectType == SubjectType.CN)
            {
                this.attrs[(object)X509Name.CN] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.CN);
            }
            if (subjectType == SubjectType.DC)
            {
                this.attrs[(object)X509Name.DC] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.DC);
            }
            if (subjectType == SubjectType.E)
            {
                this.attrs[(object)X509Name.E] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.E);
            }
            if (subjectType == SubjectType.EMAILADDRESS)
            {
                this.attrs[(object)X509Name.EmailAddress] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.EmailAddress);
            }
            if (subjectType == SubjectType.GIVENNAME)
            {
                this.attrs[(object)X509Name.GivenName] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.GivenName);
            }
            if (subjectType == SubjectType.INITIALS)
            {
                this.attrs[(object)X509Name.Initials] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.Initials);
            }
            if (subjectType == SubjectType.L)
            {
                this.attrs[(object)X509Name.L] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.L);
            }
            if (subjectType == SubjectType.NAME)
            {
                this.attrs[(object)X509Name.Name] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.Name);
            }
            if (subjectType == SubjectType.O)
            {
                this.attrs[(object)X509Name.O] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.O);
            }
            if (subjectType == SubjectType.OU)
            {
                this.attrs[(object)X509Name.OU] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.OU);
            }
            if (subjectType == SubjectType.PSEUDONYM)
            {
                this.attrs[(object)X509Name.Pseudonym] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.Pseudonym);
            }
            if (subjectType == SubjectType.SERIALNUMBER)
            {
                this.attrs[(object)X509Name.SerialNumber] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.SerialNumber);
            }
            if (subjectType == SubjectType.ST)
            {
                this.attrs[(object)X509Name.ST] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.ST);
            }
            if (subjectType == SubjectType.STREET)
            {
                this.attrs[(object)X509Name.Street] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.Street);
            }
            if (subjectType == SubjectType.SURNAME)
            {
                this.attrs[(object)X509Name.Surname] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.Surname);
            }
            if (subjectType == SubjectType.T)
            {
                this.attrs[(object)X509Name.T] = (object)subjectTypeValue;
                this.ord.Add((object)X509Name.T);
            }
            if (subjectType != SubjectType.UID)
                return;
            this.attrs[(object)X509Name.UID] = (object)subjectTypeValue;
            this.ord.Add((object)X509Name.UID);
        }

        public void LoadRootCertificate(byte[] RootPFXCertificate, string PFXFilePassword)
        {
            if (RootPFXCertificate == null)
                throw new Exception("Root PFX certificate is missing");
            switch (PFXFilePassword)
            {
                case "":
                case null:
                    throw new Exception("Root certificate password is missing");
                default:
                    Pkcs12Store pkcs12Store = new Pkcs12Store((Stream)new MemoryStream(RootPFXCertificate), PFXFilePassword.ToCharArray());
                    string alias1 = (string)null;
                    foreach (string alias2 in pkcs12Store.Aliases)
                    {
                        alias1 = alias2;
                        if (pkcs12Store.IsKeyEntry(alias1))
                            break;
                    }
                    AsymmetricKeyParameter key = pkcs12Store.GetKey(alias1).Key;
                    X509CertificateEntry[] certificateChain = pkcs12Store.GetCertificateChain(alias1);
                    ArrayList arrayList = new ArrayList();
                    this.rootCert = certificateChain[0].Certificate;
                    this.rootKeyPair = new AsymmetricCipherKeyPair(this.rootCert.GetPublicKey(), key);
                    break;
            }
        }

        public byte[] GenerateCertificate(string PFXFilePassword) => this.GenerateCertificate(PFXFilePassword, false);

        public byte[] GenerateCertificate(string PFXFilePassword, bool isRootCertificate)
        {
            try
            {
                AsymmetricCipherKeyPair asymmetricCipherKeyPair = this.MakeKeyPair(this.GetKeyLength(this.KeySize));
                AsymmetricKeyParameter key = asymmetricCipherKeyPair.Private;
                X509Name x509Name = string.IsNullOrEmpty(this.Subject) ? new X509Name((ArrayList)this.ord, (ArrayList)this.attrs) : new X509Name(true, this.Subject);
                X509Certificate cert = this.rootKeyPair == null || this.rootCert == null ? this.MakeCertificate(asymmetricCipherKeyPair, x509Name, asymmetricCipherKeyPair, x509Name, isRootCertificate, false) : this.MakeCertificate(asymmetricCipherKeyPair, x509Name, this.rootKeyPair, this.rootCert.SubjectDN, isRootCertificate, true);
                Pkcs12Store pkcs12Store = new Pkcs12Store();
                AsymmetricKeyEntry keyEntry = new AsymmetricKeyEntry(key);
                X509CertificateEntry certificateEntry1 = new X509CertificateEntry(cert);
                if (this.rootKeyPair != null && this.rootCert != null)
                {
                    X509CertificateEntry certificateEntry2 = new X509CertificateEntry(this.rootCert);
                    X509CertificateEntry[] chain = new X509CertificateEntry[2]
                    { certificateEntry1, certificateEntry2 };
                    pkcs12Store.SetKeyEntry(this.FriendlyName, keyEntry, chain);
                }
                else
                {
                    X509CertificateEntry[] chain = new X509CertificateEntry[1]{ certificateEntry1 };
                    pkcs12Store.SetKeyEntry(this.FriendlyName, keyEntry, chain);
                }
                MemoryStream memoryStream = new MemoryStream();
                pkcs12Store.Save((Stream)memoryStream, PFXFilePassword.ToCharArray(), this.GetSecureRandom());
                memoryStream.Flush();
                memoryStream.Close();
                return memoryStream.ToArray();
            }
            catch (Exception ex)
            {
                throw new CryptographicException("Cert generation error. " + ex.Message);
            }
        }

       
        public byte[] GenerateCertificateFromCSR(string CSR)
        {
            try
            {
                if (CSR == null)
                    throw new CryptographicException("CSR cannot be null.");
                if (this.rootKeyPair == null || this.rootCert == null)
                    throw new CryptographicException("Root certificate is not loaded.");
                return this.MakeCertificateFromCSR(CSR, this.rootKeyPair, this.rootCert.SubjectDN);
            }
            catch
            {
                throw;
            }
        }

        private int GetKeyLength(KeySize keySize)
        {
            switch (keySize)
            {
                case KeySize.KeySize512Bit:
                    return 512;
                case KeySize.KeySize1024Bit:
                    return 1024;
                case KeySize.KeySize2048Bit:
                    return 2048;
                case KeySize.KeySize4096Bit:
                    return 4096;
                default:
                    return 1024;
            }
        }

        private SecureRandom GetSecureRandom()
        {
            RNGCryptoServiceProvider cryptoServiceProvider = new RNGCryptoServiceProvider();
            byte[] seed = new byte[100];
            byte[] data = seed;
            cryptoServiceProvider.GetBytes(data);
            return new SecureRandom(seed);
        }

        private AsymmetricCipherKeyPair MakeKeyPair(int strenght)
        {
            try
            {
                IAsymmetricCipherKeyPairGenerator keyPairGenerator = GeneratorUtilities.GetKeyPairGenerator("RSA");
                keyPairGenerator.Init((KeyGenerationParameters)new RsaKeyGenerationParameters(BigInteger.ValueOf(65537L), this.GetSecureRandom(), strenght, 25));
                return keyPairGenerator.GenerateKeyPair();
            }
            catch
            {
                throw;
            }
        }

        private X509Certificate MakeCertificate(
          AsymmetricCipherKeyPair subjectKeyPair,
          X509Name certificateSubject,
          AsymmetricCipherKeyPair rootKeyPair,
          X509Name rootSubject,
          bool isRootCertificate,
          bool addAuthorityKeyIdentifier)
        {
            try
            {
                AsymmetricKeyParameter publicKey = subjectKeyPair.Public;
                AsymmetricKeyParameter privateKey = rootKeyPair.Private;
                AsymmetricKeyParameter asymmetricKeyParameter = rootKeyPair.Public;
                X509V3CertificateGenerator certificateGenerator = new X509V3CertificateGenerator();
                certificateGenerator.Reset();
                if (this.SerialNumber == long.MinValue)
                    certificateGenerator.SetSerialNumber(new BigInteger(128, new Random(DateTime.Now.Millisecond + Environment.TickCount)));
                else
                    certificateGenerator.SetSerialNumber(new BigInteger(this.SerialNumber.ToString()));
                certificateGenerator.SetIssuerDN(rootSubject);
                certificateGenerator.SetNotBefore(this.ValidFrom.ToUniversalTime());
                certificateGenerator.SetNotAfter(this.ValidTo.ToUniversalTime());
                certificateGenerator.SetSubjectDN(certificateSubject);
                certificateGenerator.SetPublicKey(publicKey);
                certificateGenerator.SetSignatureAlgorithm(this.SignatureAlgorithm.ToString() + "Encryption");
                int usage = 0;
                Asn1EncodableVector v1 = new Asn1EncodableVector(Array.Empty<Asn1Encodable>());
                foreach (ExtensionInfo extensionInfo in this.Extensions.extensionInfo)
                {
                    if (!extensionInfo.ExtendedKeyUsage)
                        usage |= (int)extensionInfo.ExtensionType;
                    if (extensionInfo.ExtendedKeyUsage)
                        v1.Add((Asn1Encodable)extensionInfo.ExtensionType);
                }
                bool critical = this.Extensions.KeyUsageIsCritical;
                if (isRootCertificate)
                {
                    certificateGenerator.AddExtension(X509Extensions.BasicConstraints, true, (Asn1Encodable)new BasicConstraints(true));
                    usage |= 6;
                    critical = true;
                }
                if (usage != 0)
                    certificateGenerator.AddExtension(X509Extensions.KeyUsage, critical, (Asn1Encodable)new KeyUsage(usage));
                if (v1.Count > 0)
                    certificateGenerator.AddExtension(X509Extensions.ExtendedKeyUsage, this.Extensions.EnhancedKeyUsageIsCritical, (Asn1Encodable)ExtendedKeyUsage.GetInstance((object)new DerSequence(v1)));
                if (!string.IsNullOrEmpty(this.SubjectAlternativeNames))
                {
                    Asn1EncodableVector v2 = new Asn1EncodableVector(Array.Empty<Asn1Encodable>());
                    string alternativeNames = this.SubjectAlternativeNames;
                    char[] chArray = new char[1] { ',' };
                    foreach (string str in alternativeNames.Split(chArray))
                    {
                        if (IPAddress.IsValidIPv4(str.Trim()))
                            v2.Add((Asn1Encodable)new GeneralName(7, str.Trim()));
                        else
                            v2.Add((Asn1Encodable)new GeneralName(2, str.Trim()));
                    }
                    GeneralNames extensionValue = new GeneralNames(null); // (Asn1Sequence)new DerSequence(v2));
                    certificateGenerator.AddExtension(X509Extensions.SubjectAlternativeName, false, (Asn1Encodable)extensionValue);
                }
                certificateGenerator.AddExtension(X509Extensions.SubjectKeyIdentifier, false, (Asn1Encodable)new SubjectKeyIdentifier(SubjectPublicKeyInfoFactory.CreateSubjectPublicKeyInfo(publicKey)));
                if (addAuthorityKeyIdentifier)
                    certificateGenerator.AddExtension(X509Extensions.AuthorityKeyIdentifier, false, (Asn1Encodable)new AuthorityKeyIdentifier(SubjectPublicKeyInfoFactory.CreateSubjectPublicKeyInfo(asymmetricKeyParameter)));
                X509Certificate x509Certificate = certificateGenerator.Generate(privateKey, this.GetSecureRandom());
                x509Certificate.Verify(asymmetricKeyParameter);
                return x509Certificate;
            }
            catch
            {
                throw;
            }
        }

        
        private byte[] MakeCertificateFromCSR(
          string CSR,
          AsymmetricCipherKeyPair rootKeyPair,
          X509Name rootSubject)
        {
            try
            {
                Pkcs10CertificationRequest certificationRequest = (Pkcs10CertificationRequest)new PemReader((TextReader)new StringReader(CSR)).ReadObject();
                AsymmetricKeyParameter privateKey = rootKeyPair.Private;
                AsymmetricKeyParameter asymmetricKeyParameter = rootKeyPair.Public;
                X509V3CertificateGenerator certificateGenerator = new X509V3CertificateGenerator();
                certificateGenerator.Reset();
                if (this.SerialNumber == long.MinValue)
                    certificateGenerator.SetSerialNumber(new BigInteger(128, new Random(DateTime.Now.Millisecond + Environment.TickCount)));
                else
                    certificateGenerator.SetSerialNumber(new BigInteger(this.SerialNumber.ToString()));
                certificateGenerator.SetIssuerDN(rootSubject);
                certificateGenerator.SetNotBefore(this.ValidFrom.ToUniversalTime());
                certificateGenerator.SetNotAfter(this.ValidTo.ToUniversalTime());
                certificateGenerator.SetSubjectDN(certificationRequest.GetCertificationRequestInfo().Subject);
                certificateGenerator.SetPublicKey(certificationRequest.GetPublicKey());
                certificateGenerator.SetSignatureAlgorithm(this.SignatureAlgorithm.ToString() + "Encryption");
                certificateGenerator.AddExtension(X509Extensions.SubjectKeyIdentifier, false, (Asn1Encodable)new SubjectKeyIdentifier(SubjectPublicKeyInfoFactory.CreateSubjectPublicKeyInfo(certificationRequest.GetPublicKey())));
                certificateGenerator.AddExtension(X509Extensions.AuthorityKeyIdentifier, false, (Asn1Encodable)new AuthorityKeyIdentifier(SubjectPublicKeyInfoFactory.CreateSubjectPublicKeyInfo(asymmetricKeyParameter)));
                int usage = 0;
                Asn1EncodableVector v1 = new Asn1EncodableVector(Array.Empty<Asn1Encodable>());
                foreach (ExtensionInfo extensionInfo in this.Extensions.extensionInfo)
                {
                    if (!extensionInfo.ExtendedKeyUsage)
                        usage |= (int)extensionInfo.ExtensionType;
                    if (extensionInfo.ExtendedKeyUsage)
                        v1.Add((Asn1Encodable)extensionInfo.ExtensionType);
                }
                if (usage != 0)
                    certificateGenerator.AddExtension(X509Extensions.KeyUsage, this.Extensions.KeyUsageIsCritical, (Asn1Encodable)new KeyUsage(usage));
                if (v1.Count > 0)
                    certificateGenerator.AddExtension(X509Extensions.ExtendedKeyUsage, this.Extensions.EnhancedKeyUsageIsCritical, (Asn1Encodable)ExtendedKeyUsage.GetInstance((object)new DerSequence(v1)));
                if (!string.IsNullOrEmpty(this.SubjectAlternativeNames))
                {
                    Asn1EncodableVector v2 = new Asn1EncodableVector(Array.Empty<Asn1Encodable>());
                    string alternativeNames = this.SubjectAlternativeNames;
                    char[] chArray = new char[1] { ',' };
                    foreach (string str in alternativeNames.Split(chArray))
                    {
                        if (IPAddress.IsValidIPv4(str.Trim()))
                            v2.Add((Asn1Encodable)new GeneralName(7, str.Trim()));
                        else
                            v2.Add((Asn1Encodable)new GeneralName(2, str.Trim()));
                    }
                    GeneralNames extensionValue = new GeneralNames(null);// (Asn1Sequence)new DerSequence(v2));
                    certificateGenerator.AddExtension(X509Extensions.SubjectAlternativeName, false, (Asn1Encodable)extensionValue);
                }
                X509Certificate x509Certificate = certificateGenerator.Generate(privateKey, this.GetSecureRandom());
                x509Certificate.Verify(asymmetricKeyParameter);
                return x509Certificate.GetEncoded();
            }
            catch
            {
                throw;
            }
        }
        


        public static void Main()
        {
            //GenerateCARoot();
            //CreateDigitalCertificate();
            Console.WriteLine("LxTools.X509Genertor 1.0");
        }

        
        static SyCert.X509Certificate2 CreateDigitalCert( string Subject, string fileName, string password, int maxMeses=3, string caRootPfx="", string caRootPass="" )
        {

            X509CertificatesX certGenerator = new X509CertificatesX();

            certGenerator.ValidFrom = DateTime.Now;
            //certGenerator.ValidTo = DateTime.Now.AddYears(1);
            certGenerator.ValidTo = DateTime.Now.AddMonths( maxMeses );

            //set the signing algorithm and the key size
            certGenerator.KeySize = KeySize.KeySize2048Bit;// KeySize.KeySize1024Bit;
            certGenerator.SignatureAlgorithm = SignatureAlgorithm.SHA256WithRSA;

            //set the certificate sobject
            //certGenerator.Subject = "CN=MELGAREJO BOLIVAR Romel Percy FAU DNI 45526606, OU=UNA PUNO - DIGITAL SIGNATURE, O=UNIVERSIDAD NACIONAL DEL ALTIPLANO PUNO, E=permelro@unap.edu.pe";
            //certGenerator.Subject = "CN=LAURA MURILLO Ramiro Pedro DNI 41939172, OU=UNIVERSIDAD NACIONAL DEL ALTIPLANO PUNO - FIRMA DIGITAL, O=UNIVERSIDAD NACIONAL DEL ALTIPLANO PUNO, E=rlaura@unap.edu.pe, SERIALNUMBER=DNI:41939172";
            //certGenerator.Subject = "CN=MAZCO PUMA Josue DNI 44274795, OU=JOSSMP BUSSINES, O=JOSSMP BUSSINES, E=jossmp@hotmail.com, SERIALNUMBER=DNI:44274795";
            //certGenerator.Subject = "CN=COLEGIO PROFESIONAL PUNO, OU=AGENTE AUTOMATIZADO, OU=Validado por COESPE, O=COLEGIO DE PROFESIONALES PUNO, E=decano@pepuno.pe, STREET=JR. JKLM NRO. 227";
            //certGenerator.Subject = "CN=UNIVERSIDAD NACIONAL MICAELA BASTIDAS, OU=AGENTE AUTOMATIZADO, OU=Validado por CA Cert-PE, O=Universidad Nacional Micaela Bastidas, E=informes@unamba.edu.pe, STREET=JR. JKLM NRO. 227";
            //certGenerator.Subject = "CN=UNIVERSIDAD NACIONAL DEL ALTIPLANO, OU=AGENTE AUTOMATIZADO, OU=Validado por CA Cert-PE, O=Universidad Nacional del Altiplano - Puno, E=gdigital@unap.edu.pe, STREET=AV. FLORAL S/N";
            certGenerator.Subject = Subject;



            //certGenerator.LoadRootCertificate(File.ReadAllBytes("RootCAco.pfx"), "12345");
            //certGenerator.LoadRootCertificate(File.ReadAllBytes("entrust_2048_ca.cer"), "123456789123456");


            if ( caRootPfx != "" )
                certGenerator.LoadRootCertificate(File.ReadAllBytes(caRootPfx), caRootPass);



            //add some simple extensions to the client certificate
            certGenerator.Extensions.AddKeyUsage(CertificateKeyUsage.DigitalSignature);
            certGenerator.Extensions.AddKeyUsage(CertificateKeyUsage.NonRepudiation);

            //add some enhanced extensions to the client certificate marked as critical
            certGenerator.Extensions.AddEnhancedKeyUsage(CertificateEnhancedKeyUsage.DocumentSigning);
            certGenerator.Extensions.AddEnhancedKeyUsage(CertificateEnhancedKeyUsage.ClientAuthentication);

            //File.WriteAllBytes("certVri.pfx", certGenerator.GenerateCertificate("vri2021", false));
            //File.WriteAllBytes("certRm.pfx", certGenerator.GenerateCertificate("finesi", false));
            //File.WriteAllBytes("certCoespeCR.pfx", certGenerator.GenerateCertificate("12345", false));
            //File.WriteAllBytes("unamba.pfx", certGenerator.GenerateCertificate("Unamba_X2024z", false));
            //File.WriteAllBytes("unap.pfx", certGenerator.GenerateCertificate("finesi++", false));

            // local copy of PFX
            File.WriteAllBytes( fileName, certGenerator.GenerateCertificate(password, false));

            //convert the resulting PFX certificate to X509Certificate2 that can be used by .NET
            return new System.Security.Cryptography.X509Certificates.X509Certificate2(certGenerator.GenerateCertificate(password, false), password);
        }
        

        
        static SyCert.X509Certificate2 GenerateCARoot( string Subject, string fileName, string password, int maxMeses=3 )
        {
            X509CertificatesX certGenerator = new X509CertificatesX();

            certGenerator.ValidFrom = DateTime.Now;
            //certGenerator.ValidTo = DateTime.Now.AddYears(2);
            certGenerator.ValidTo = DateTime.Now.AddMonths( maxMeses );

            //set the signing algorithm and the key size
            certGenerator.KeySize = KeySize.KeySize2048Bit;// KeySize.KeySize1024Bit;
            certGenerator.SignatureAlgorithm = SignatureAlgorithm.SHA256WithRSA;

            //set the certificate subject
            //certGenerator.Subject = "CN=Vicerrectorado de Investigación, OU=UNIVERSIDAD NACIONAL DEL ALTIPLANO PUNO (OPID VRI), O=UNIVERSIDAD NACIONAL DEL ALTIPLANO PUNO";
            //certGenerator.Subject = "CN=COESPE CA ROOT, OU=COLEGIO DE ESTADISTICOS DEL PERU, O=COLEGIO DE ESTADISTICOS DEL PERU";
            certGenerator.Subject = "CN=CA CERT-PE ROOT, OU=CA CERT-PE, O=CA CERT-PE";
            certGenerator.Subject = Subject; // this one

            //certGenerator.LoadRootCertificate
            bool isRootCertificate = true;

            //add some simple extensions to the client certificate
            certGenerator.Extensions.AddKeyUsage(CertificateKeyUsage.DigitalSignature);
            certGenerator.Extensions.AddKeyUsage(CertificateKeyUsage.NonRepudiation);

            //add some enhanced extensions to the client certificate marked as critical
            certGenerator.Extensions.AddEnhancedKeyUsage(CertificateEnhancedKeyUsage.DocumentSigning);
            certGenerator.Extensions.AddEnhancedKeyUsage(CertificateEnhancedKeyUsage.ClientAuthentication);

            // grabamos archivo para repositorio interno
            File.WriteAllBytes( fileName, certGenerator.GenerateCertificate( password, isRootCertificate));

            //convert the resulting PFX certificate to X509Certificate2 that can be used by .NET
            return new System.Security.Cryptography.X509Certificates.X509Certificate2(certGenerator.GenerateCertificate(password, true), password);
        }
    }
}



